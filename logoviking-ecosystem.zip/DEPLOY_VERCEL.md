# 🚀 Deploy Logoviking to Vercel

This project is **fully configured** for Vercel. You have 3 easy ways to deploy.

---

## ✅ Option 1 — Deploy via GitHub (recommended, most popular)

### Step 1 — Push your project to GitHub

Open a terminal in the project folder and run:

```bash
git init
git add .
git commit -m "Initial Logoviking commit"
```

Create a new empty repo on [GitHub](https://github.com/new) (name it `logoviking`), then:

```bash
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/logoviking.git
git push -u origin main
```

### Step 2 — Import to Vercel

1. Go to **[vercel.com/new](https://vercel.com/new)**
2. Sign in with GitHub (free)
3. Click **"Import"** next to your `logoviking` repo
4. Vercel will **auto-detect Vite** — leave all settings as-is
5. Click **"Deploy"**

⏱️ ~60 seconds later, your site is live at `https://logoviking-xxxxx.vercel.app`

### Step 3 — Add your custom domain (logoviking.com)

1. In Vercel dashboard → **Project Settings** → **Domains**
2. Type `logoviking.com` → **Add**
3. Vercel shows you DNS records to add at your domain registrar
4. Add them → wait ~5 minutes → SSL is automatic and free

---

## ✅ Option 2 — Deploy via Vercel CLI (fastest)

### Step 1 — Install the CLI
```bash
npm i -g vercel
```

### Step 2 — Deploy
From inside the project folder:
```bash
vercel
```
Follow the prompts:
- **Set up and deploy?** → Yes
- **Which scope?** → Pick your account
- **Link to existing project?** → No
- **What's your project name?** → `logoviking`
- **In which directory is your code located?** → `./`
- **Override settings?** → No (Vite is auto-detected)

When done, you get a preview URL. To deploy to production:
```bash
vercel --prod
```

---

## ✅ Option 3 — Deploy by dragging a folder

1. Run `npm run build` locally
2. Go to [vercel.com/new](https://vercel.com/new)
3. Click **"deploy a different repository"** → **"Import a project"** → **"Deploy a static site"**
4. Drag the entire **project folder** (not just `dist/`) into the browser
5. Vercel handles the rest

---

## 📦 What was configured for you

| File | Purpose |
|---|---|
| `vercel.json` | Build settings + SPA rewrites + security headers + cache rules |
| `.vercelignore` | Skips `server.js`, `node_modules`, `dist`, docs from upload |
| `.gitignore` | Standard ignores for git |

### `vercel.json` highlights
- **Framework:** auto-detects Vite
- **Build:** `npm run build` → outputs to `dist/`
- **SPA fallback:** All non-file routes serve `index.html` (React Router works)
- **Security headers:** HSTS, X-Frame, Referrer-Policy, Permissions-Policy
- **Cache headers:**
  - sitemaps/robots.txt → 1 hour
  - images → 30 days immutable
  - manifests → 1 day
- **Clean URLs:** `/about` instead of `/about.html`

---

## 🔐 Environment Variables on Vercel

If you set any of these in `.env.example`, add them in:
**Vercel Dashboard → Project Settings → Environment Variables**

| Variable | Required? | Notes |
|---|---|---|
| `VITE_GOOGLE_CLIENT_ID` | Optional | Enables real Google Sign-In |
| `VITE_GA4_MEASUREMENT_ID` | Optional | Enables GA4 tracking |
| `VITE_ADSENSE_PUBLISHER_ID` | Optional | Leave blank until AdSense is approved |
| `VITE_ADSENSE_ENABLED` | Optional | Keep `false` until you get traffic |

After adding env vars, **redeploy** (Vercel does this automatically with one click).

---

## ❓ Common questions

**Q: Do I need server.js on Vercel?**
A: No. Vercel serves the static `dist/` folder. `server.js` is only for Hostinger and is **excluded** by `.vercelignore`.

**Q: Will my sitemaps and robots.txt work?**
A: Yes. They're emitted into `dist/` at build time and served by Vercel with correct content types.

**Q: Will React Router routes work?**
A: Yes. The `rewrites` rule in `vercel.json` sends all routes that aren't files to `index.html`.

**Q: Free tier limits?**
A: Vercel free tier gives you **100 GB bandwidth/month** + **unlimited deploys** — more than enough for a launching site.

**Q: How fast will it be?**
A: Vercel serves from a global edge CDN — typical load time under 200 ms worldwide.

---

## ✅ After deployment — verify checklist

Open your deployed URL and check:

- [ ] Home page loads
- [ ] Click "Tools" → see all 60+ tools
- [ ] Open a tool (e.g. `/tools/compress-image`)
- [ ] Refresh that page → still loads (SPA routing works)
- [ ] Visit `/robots.txt` → returns text
- [ ] Visit `/sitemap-index.xml` → returns XML
- [ ] Visit `/site.webmanifest` → returns JSON
- [ ] Open language picker → modal centers correctly
- [ ] Open color picker → theme changes apply
- [ ] Try Background Remover with an image
- [ ] Check Lighthouse: should be 90+ on all 4 metrics

---

## 🆘 Troubleshooting

**Build fails on Vercel but works locally**
- Make sure `node` version matches. Add to `package.json`:
  ```json
  "engines": { "node": ">=22" }
  ```

**404 on direct URL like `/tools/compress-image`**
- Means rewrites aren't applied. Confirm `vercel.json` is at the project root.

**Images not loading**
- Confirm they're in `public/images/` and use absolute paths like `/images/foo.png`.

---

🎉 **You're ready to deploy!** Pick Option 1 (GitHub) for the best long-term workflow — every git push auto-deploys.
