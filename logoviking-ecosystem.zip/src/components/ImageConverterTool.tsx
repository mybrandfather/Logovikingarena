import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  ImageIcon,
  Download,
  Zap,
  RefreshCw,
  X,
  Check,
  Trash2,
  Shield,
  Sparkles,
  ArrowRight,
} from "lucide-react";

/**
 * ImageConverterTool — 100% client-side image converter / compressor / resizer.
 * No uploads ever leave the browser; everything runs through the Canvas API.
 *
 * Loaded lazily (see App.tsx) so the heavy bits stay out of the main bundle.
 * JSZip is pulled from a CDN on demand only when the user clicks "Download ZIP".
 */

export type ConverterMode =
  | "jpg-to-webp"
  | "png-to-webp"
  | "webp-to-jpg"
  | "compress"
  | "resize";

type Tier = "guest" | "free" | "premium";

type OutFormat = "image/webp" | "image/jpeg" | "image/png";

type Job = {
  id: string;
  file: File;
  status: "queued" | "working" | "done" | "error";
  error?: string;
  previewUrl: string;
  outUrl?: string;
  outBlob?: Blob;
  outName?: string;
  inBytes: number;
  outBytes?: number;
  width?: number;
  height?: number;
};

const MODE_CONFIG: Record<
  ConverterMode,
  {
    title: string;
    accept: string;
    out: OutFormat;
    lossy: boolean;
    extension: string;
    blurb: string;
  }
> = {
  "jpg-to-webp": {
    title: "JPG → WebP",
    accept: "image/jpeg,image/jpg",
    out: "image/webp",
    lossy: true,
    extension: "webp",
    blurb: "Convert JPG photos to lightweight WebP — typically 25–35% smaller at the same quality.",
  },
  "png-to-webp": {
    title: "PNG → WebP",
    accept: "image/png",
    out: "image/webp",
    lossy: true,
    extension: "webp",
    blurb: "Turn PNG graphics into WebP while keeping transparency. Great for logos and UI assets.",
  },
  "webp-to-jpg": {
    title: "WebP → JPG",
    accept: "image/webp",
    out: "image/jpeg",
    lossy: true,
    extension: "jpg",
    blurb: "Convert WebP back to universally-supported JPG for email, print, and legacy apps.",
  },
  compress: {
    title: "Compress Image",
    accept: "image/jpeg,image/jpg,image/png,image/webp",
    out: "image/webp",
    lossy: true,
    extension: "webp",
    blurb: "Shrink JPG, PNG, or WebP files with a quality you control. Perfect for faster pages.",
  },
  resize: {
    title: "Resize Image",
    accept: "image/jpeg,image/jpg,image/png,image/webp",
    out: "image/png",
    lossy: false,
    extension: "png",
    blurb: "Set an exact width or height. Aspect ratio is locked by default so nothing is squashed.",
  },
};

const FREE_BATCH_LIMIT = 10;
const MAX_FILE_MB = 25;
const JSZIP_CDN = "https://cdn.jsdelivr.net/npm/jszip@3.10.1/+esm";

function fmtBytes(b: number): string {
  if (b < 1024) return `${b} B`;
  if (b < 1024 * 1024) return `${(b / 1024).toFixed(1)} KB`;
  return `${(b / (1024 * 1024)).toFixed(2)} MB`;
}

function baseName(name: string): string {
  const dot = name.lastIndexOf(".");
  return dot > 0 ? name.slice(0, dot) : name;
}

function loadImage(url: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("This file could not be read as an image."));
    img.src = url;
  });
}

function canvasToBlob(canvas: HTMLCanvasElement, type: string, quality: number): Promise<Blob> {
  return new Promise((resolve, reject) => {
    canvas.toBlob(
      (blob) => (blob ? resolve(blob) : reject(new Error("Your browser could not encode this image."))),
      type,
      quality
    );
  });
}

export default function ImageConverterTool({
  mode,
  tier = "guest",
}: {
  mode: ConverterMode;
  tier?: Tier;
}) {
  const cfg = MODE_CONFIG[mode];
  const isPremium = tier === "premium";
  const batchLimit = isPremium ? Infinity : FREE_BATCH_LIMIT;

  const [jobs, setJobs] = useState<Job[]>([]);
  const [quality, setQuality] = useState(82);
  const [outFormat, setOutFormat] = useState<OutFormat>(cfg.out);
  const [targetWidth, setTargetWidth] = useState<number>(1280);
  const [lockAspect, setLockAspect] = useState(true);
  const [dragActive, setDragActive] = useState(false);
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState(0);
  const [zipping, setZipping] = useState(false);
  const [notice, setNotice] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const jobsRef = useRef<Job[]>([]);
  jobsRef.current = jobs;

  // Revoke every object URL we created when the component unmounts.
  useEffect(() => {
    return () => {
      jobsRef.current.forEach((j) => {
        URL.revokeObjectURL(j.previewUrl);
        if (j.outUrl) URL.revokeObjectURL(j.outUrl);
      });
    };
  }, []);

  const effectiveOut: OutFormat = mode === "compress" ? outFormat : cfg.out;
  const effectiveExt =
    effectiveOut === "image/webp" ? "webp" : effectiveOut === "image/jpeg" ? "jpg" : "png";

  const addFiles = useCallback(
    (fileList: FileList | File[]) => {
      setNotice("");
      const incoming = Array.from(fileList).filter((f) => f.type.startsWith("image/"));
      if (incoming.length === 0) {
        setNotice("Those files aren't images. Add PNG, JPG, or WebP files.");
        return;
      }
      const tooBig = incoming.find((f) => f.size > MAX_FILE_MB * 1024 * 1024);
      if (tooBig) {
        setNotice(`"${tooBig.name}" is over ${MAX_FILE_MB} MB. Try a smaller file.`);
      }
      const accepted = incoming.filter((f) => f.size <= MAX_FILE_MB * 1024 * 1024);

      setJobs((prev) => {
        const room = batchLimit - prev.length;
        if (room <= 0) {
          setNotice(
            `Free plan processes ${FREE_BATCH_LIMIT} images per batch. Upgrade for unlimited batches.`
          );
          return prev;
        }
        const slice = accepted.slice(0, room);
        if (slice.length < accepted.length) {
          setNotice(
            `Added ${slice.length} of ${accepted.length}. Free plan caps batches at ${FREE_BATCH_LIMIT} — upgrade for unlimited.`
          );
        }
        const next = slice.map<Job>((file) => ({
          id: `${file.name}-${file.size}-${Math.random().toString(36).slice(2, 8)}`,
          file,
          status: "queued",
          previewUrl: URL.createObjectURL(file),
          inBytes: file.size,
        }));
        return [...prev, ...next];
      });
    },
    [batchLimit]
  );

  const onDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setDragActive(false);
      if (e.dataTransfer?.files?.length) addFiles(e.dataTransfer.files);
    },
    [addFiles]
  );

  const removeJob = useCallback((id: string) => {
    setJobs((prev) => {
      const job = prev.find((j) => j.id === id);
      if (job) {
        URL.revokeObjectURL(job.previewUrl);
        if (job.outUrl) URL.revokeObjectURL(job.outUrl);
      }
      return prev.filter((j) => j.id !== id);
    });
  }, []);

  const clearAll = useCallback(() => {
    jobsRef.current.forEach((j) => {
      URL.revokeObjectURL(j.previewUrl);
      if (j.outUrl) URL.revokeObjectURL(j.outUrl);
    });
    setJobs([]);
    setProgress(0);
    setNotice("");
  }, []);

  async function processOne(job: Job): Promise<Partial<Job>> {
    const img = await loadImage(job.previewUrl);
    let w = img.naturalWidth;
    let h = img.naturalHeight;

    if (mode === "resize" && targetWidth > 0) {
      const ratio = img.naturalHeight / img.naturalWidth;
      w = Math.round(targetWidth);
      h = lockAspect ? Math.round(targetWidth * ratio) : img.naturalHeight;
    }

    const canvas = document.createElement("canvas");
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("Canvas is not supported in this browser.");

    // JPEG has no alpha channel — paint a white backdrop so transparency
    // doesn't turn black.
    if (effectiveOut === "image/jpeg") {
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, w, h);
    }
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = "high";
    ctx.drawImage(img, 0, 0, w, h);

    const q = cfg.lossy || mode === "compress" ? quality / 100 : 0.92;
    const blob = await canvasToBlob(canvas, effectiveOut, q);
    const outUrl = URL.createObjectURL(blob);
    return {
      status: "done",
      outBlob: blob,
      outUrl,
      outBytes: blob.size,
      outName: `${baseName(job.file.name)}.${effectiveExt}`,
      width: w,
      height: h,
    };
  }

  const runAll = useCallback(async () => {
    const queue = jobsRef.current.filter((j) => j.status === "queued" || j.status === "error");
    if (queue.length === 0) return;
    setBusy(true);
    setProgress(0);
    setNotice("");
    let done = 0;
    for (const job of queue) {
      setJobs((prev) => prev.map((j) => (j.id === job.id ? { ...j, status: "working" } : j)));
      try {
        const patch = await processOne(job);
        setJobs((prev) => prev.map((j) => (j.id === job.id ? { ...j, ...patch } : j)));
      } catch (err) {
        const message = err instanceof Error ? err.message : "Conversion failed.";
        setJobs((prev) =>
          prev.map((j) => (j.id === job.id ? { ...j, status: "error", error: message } : j))
        );
      }
      done += 1;
      setProgress(Math.round((done / queue.length) * 100));
    }
    setBusy(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mode, quality, outFormat, targetWidth, lockAspect]);

  const downloadOne = useCallback((job: Job) => {
    if (!job.outUrl || !job.outName) return;
    const a = document.createElement("a");
    a.href = job.outUrl;
    a.download = job.outName;
    document.body.appendChild(a);
    a.click();
    a.remove();
  }, []);

  const downloadZip = useCallback(async () => {
    const ready = jobsRef.current.filter((j) => j.status === "done" && j.outBlob);
    if (ready.length === 0) return;
    setZipping(true);
    setNotice("");
    try {
      const mod = (await import(/* @vite-ignore */ JSZIP_CDN)) as {
        default: new () => {
          file: (name: string, data: Blob) => void;
          generateAsync: (opts: { type: "blob" }) => Promise<Blob>;
        };
      };
      const zip = new mod.default();
      const used = new Set<string>();
      ready.forEach((j) => {
        let name = j.outName ?? "image";
        let i = 1;
        while (used.has(name)) {
          name = `${baseName(j.outName ?? "image")}-${i}.${effectiveExt}`;
          i += 1;
        }
        used.add(name);
        if (j.outBlob) zip.file(name, j.outBlob);
      });
      const blob = await zip.generateAsync({ type: "blob" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `logoviking-${mode}.zip`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 4000);
    } catch {
      setNotice("Couldn't build the ZIP. Download files individually instead.");
    } finally {
      setZipping(false);
    }
  }, [mode, effectiveExt]);

  const stats = useMemo(() => {
    const done = jobs.filter((j) => j.status === "done");
    const inTotal = done.reduce((s, j) => s + j.inBytes, 0);
    const outTotal = done.reduce((s, j) => s + (j.outBytes ?? 0), 0);
    const saved = inTotal > 0 ? Math.round((1 - outTotal / inTotal) * 100) : 0;
    return { count: done.length, inTotal, outTotal, saved };
  }, [jobs]);

  const queuedCount = jobs.filter((j) => j.status === "queued" || j.status === "error").length;
  const doneCount = stats.count;

  return (
    <div className="space-y-5">
      {/* Drop zone */}
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setDragActive(true);
        }}
        onDragLeave={() => setDragActive(false)}
        onDrop={onDrop}
        className={
          "relative overflow-hidden rounded-3xl border-2 border-dashed p-8 text-center transition-all backdrop-blur-xl " +
          (dragActive
            ? "border-violet-500 bg-violet-50/80 dark:bg-violet-950/30"
            : "border-gray-300 bg-white/60 hover:border-violet-400 dark:border-gray-700 dark:bg-gray-900/50")
        }
      >
        <div className="pointer-events-none absolute -right-16 -top-16 h-48 w-48 rounded-full bg-gradient-to-br from-violet-500/20 to-cyan-400/20 blur-3xl" />
        <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-violet-600 to-cyan-500 shadow-lg shadow-violet-500/30">
          <ImageIcon size={26} className="text-white" />
        </div>
        <p className="text-base font-semibold text-gray-900 dark:text-white">
          Drag & drop images, or{" "}
          <button
            onClick={() => inputRef.current?.click()}
            className="text-violet-600 underline-offset-2 hover:underline dark:text-violet-400"
          >
            browse
          </button>
        </p>
        <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">{cfg.blurb}</p>
        <p className="mt-3 inline-flex items-center gap-1.5 rounded-full bg-emerald-50 px-3 py-1 text-xs font-medium text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300">
          <Shield size={12} /> Files never leave your device — processed 100% in your browser
        </p>
        <input
          ref={inputRef}
          type="file"
          accept={cfg.accept}
          multiple
          onChange={(e) => e.target.files && addFiles(e.target.files)}
          className="hidden"
        />
      </div>

      {/* Controls */}
      <div className="grid gap-4 rounded-2xl border border-gray-200 bg-white/70 p-4 backdrop-blur-xl dark:border-gray-800 dark:bg-gray-900/60 sm:grid-cols-2">
        {(cfg.lossy || mode === "compress") && (
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-200">
            Quality — <span className="font-semibold text-violet-600 dark:text-violet-400">{quality}%</span>
            <input
              type="range"
              min={40}
              max={100}
              value={quality}
              onChange={(e) => setQuality(Number(e.target.value))}
              className="mt-2 block w-full accent-violet-600"
            />
            <span className="text-xs text-gray-400">Lower = smaller file. 80–85% is a good balance.</span>
          </label>
        )}

        {mode === "compress" && (
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-200">
            Output format
            <select
              value={outFormat}
              onChange={(e) => setOutFormat(e.target.value as OutFormat)}
              className="mt-2 block w-full rounded-xl border border-gray-200 bg-gray-50 px-3 py-2.5 text-sm dark:border-gray-700 dark:bg-gray-800 dark:text-white"
            >
              <option value="image/webp">WebP (smallest)</option>
              <option value="image/jpeg">JPEG (most compatible)</option>
            </select>
          </label>
        )}

        {mode === "resize" && (
          <>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-200">
              Target width (px)
              <input
                type="number"
                min={16}
                max={8000}
                value={targetWidth}
                onChange={(e) => setTargetWidth(Number(e.target.value))}
                className="mt-2 block w-full rounded-xl border border-gray-200 bg-gray-50 px-3 py-2.5 text-sm dark:border-gray-700 dark:bg-gray-800 dark:text-white"
              />
            </label>
            <label className="flex items-center gap-2 self-end pb-2 text-sm font-medium text-gray-700 dark:text-gray-200">
              <input
                type="checkbox"
                checked={lockAspect}
                onChange={(e) => setLockAspect(e.target.checked)}
                className="h-4 w-4 accent-violet-600"
              />
              Maintain aspect ratio
            </label>
          </>
        )}
      </div>

      {notice && (
        <p className="rounded-xl border border-amber-200 bg-amber-50 px-4 py-2.5 text-sm text-amber-800 dark:border-amber-800 dark:bg-amber-950/30 dark:text-amber-200">
          {notice}
        </p>
      )}

      {/* Action bar */}
      {jobs.length > 0 && (
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={runAll}
            disabled={busy || queuedCount === 0}
            className={
              "flex items-center gap-2 rounded-xl bg-violet-600 px-4 py-2.5 text-sm font-semibold text-white shadow-sm shadow-violet-500/20 transition-all hover:bg-violet-700 " +
              (busy || queuedCount === 0 ? "cursor-not-allowed opacity-60" : "")
            }
          >
            {busy ? <RefreshCw size={15} className="animate-spin" /> : <Zap size={15} />}
            {busy ? `Converting… ${progress}%` : `Convert ${queuedCount || ""}`.trim()}
          </button>
          <button
            onClick={downloadZip}
            disabled={zipping || doneCount === 0}
            className={
              "flex items-center gap-2 rounded-xl border border-violet-200 bg-violet-50 px-4 py-2.5 text-sm font-semibold text-violet-700 transition-all hover:bg-violet-100 dark:border-violet-800 dark:bg-violet-950/30 dark:text-violet-300 " +
              (zipping || doneCount === 0 ? "cursor-not-allowed opacity-60" : "")
            }
          >
            {zipping ? <RefreshCw size={15} className="animate-spin" /> : <Download size={15} />}
            {zipping ? "Zipping…" : "Download ZIP"}
          </button>
          <button
            onClick={clearAll}
            className="flex items-center gap-2 rounded-xl border border-gray-200 px-4 py-2.5 text-sm font-semibold text-gray-600 hover:bg-gray-50 dark:border-gray-700 dark:text-gray-300 dark:hover:bg-gray-800"
          >
            <Trash2 size={15} /> Clear
          </button>
        </div>
      )}

      {/* Progress bar */}
      {busy && (
        <div className="h-1.5 w-full overflow-hidden rounded-full bg-gray-100 dark:bg-gray-800">
          <motion.div
            className="h-full bg-gradient-to-r from-violet-600 to-cyan-500"
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            transition={{ ease: "easeOut", duration: 0.25 }}
          />
        </div>
      )}

      {/* Savings summary */}
      {doneCount > 0 && (
        <div className="flex flex-wrap items-center gap-x-6 gap-y-1 rounded-2xl border border-emerald-200 bg-emerald-50/70 px-4 py-3 text-sm dark:border-emerald-900 dark:bg-emerald-950/20">
          <span className="font-semibold text-emerald-700 dark:text-emerald-300">
            {doneCount} image{doneCount > 1 ? "s" : ""} ready
          </span>
          <span className="text-gray-600 dark:text-gray-400">
            {fmtBytes(stats.inTotal)} → {fmtBytes(stats.outTotal)}
          </span>
          {stats.saved > 0 && (
            <span className="font-semibold text-emerald-700 dark:text-emerald-300">
              {stats.saved}% smaller
            </span>
          )}
        </div>
      )}

      {/* File cards */}
      <div className="grid gap-3">
        <AnimatePresence initial={false}>
          {jobs.map((job) => {
            const reduction =
              job.outBytes && job.inBytes
                ? Math.round((1 - job.outBytes / job.inBytes) * 100)
                : 0;
            return (
              <motion.div
                key={job.id}
                layout
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.97 }}
                className="flex items-center gap-4 rounded-2xl border border-gray-200 bg-white/80 p-3 backdrop-blur-xl dark:border-gray-800 dark:bg-gray-900/60"
              >
                <img
                  src={job.outUrl ?? job.previewUrl}
                  alt={job.file.name}
                  className="h-16 w-16 shrink-0 rounded-xl object-cover ring-1 ring-black/5"
                />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium text-gray-900 dark:text-white">
                    {job.outName ?? job.file.name}
                  </p>
                  <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-0.5 text-xs text-gray-500 dark:text-gray-400">
                    <span>{fmtBytes(job.inBytes)}</span>
                    {job.outBytes != null && (
                      <>
                        <ArrowRight size={11} />
                        <span className="font-semibold text-gray-700 dark:text-gray-200">
                          {fmtBytes(job.outBytes)}
                        </span>
                        {reduction !== 0 && (
                          <span
                            className={
                              reduction > 0
                                ? "font-semibold text-emerald-600 dark:text-emerald-400"
                                : "font-semibold text-amber-600 dark:text-amber-400"
                            }
                          >
                            {reduction > 0 ? `−${reduction}%` : `+${Math.abs(reduction)}%`}
                          </span>
                        )}
                      </>
                    )}
                    {job.width != null && (
                      <span>
                        {job.width}×{job.height}px
                      </span>
                    )}
                  </div>
                  {job.status === "error" && (
                    <p className="mt-1 text-xs text-rose-600 dark:text-rose-400">{job.error}</p>
                  )}
                </div>

                <div className="flex shrink-0 items-center gap-1.5">
                  {job.status === "working" && (
                    <RefreshCw size={16} className="animate-spin text-violet-600 dark:text-violet-400" />
                  )}
                  {job.status === "done" && (
                    <button
                      onClick={() => downloadOne(job)}
                      className="flex items-center gap-1.5 rounded-lg bg-gray-900 px-3 py-1.5 text-xs font-semibold text-white dark:bg-white dark:text-gray-900"
                    >
                      <Download size={13} /> Save
                    </button>
                  )}
                  {job.status === "done" && (
                    <Check size={16} className="text-emerald-500" />
                  )}
                  <button
                    onClick={() => removeJob(job.id)}
                    aria-label="Remove"
                    className="rounded-lg p-1.5 text-gray-400 hover:bg-gray-100 hover:text-gray-600 dark:hover:bg-gray-800"
                  >
                    <X size={16} />
                  </button>
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>

      {/* Free-tier ad placeholder + upgrade nudge */}
      {!isPremium && (
        <div className="rounded-2xl border border-dashed border-gray-200 bg-white/50 p-4 text-center dark:border-gray-700 dark:bg-gray-900/40">
          <p className="text-xs font-medium text-gray-400 dark:text-gray-500">Advertisement</p>
          <div className="mt-2 h-16 rounded-xl bg-gray-50 dark:bg-gray-800/60" />
          <p className="mt-3 inline-flex items-center gap-1.5 text-xs text-violet-700 dark:text-violet-300">
            <Sparkles size={13} /> Upgrade to remove ads and unlock unlimited batch processing.
          </p>
        </div>
      )}
    </div>
  );
}
